<?php

$client = new http\Client;
$request = new http\Client\Request;

$body = new http\Message\Body;
$body->append('{"scope":"store/order/updated","destination":"https://test.dealsfordell.com/webhooks","is_active":true}');

$request->setRequestUrl('https://api.bigcommerce.com/stores/ino7fxpsg3/v3/hooks');
$request->setRequestMethod('POST');
$request->setBody($body);

$request->setHeaders(array(
  'accept' => 'application/json',
  'content-type' => 'application/json',
  'x-auth-token' => 'sjazb4qseyl6canff4p8e2gypxvq59a'
));

$client->enqueue($request)->send();
$response = $client->getResponse();

echo $response->getBody();

?>